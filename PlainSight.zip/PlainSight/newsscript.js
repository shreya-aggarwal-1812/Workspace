ffunction showSection(sectionId) {
    // Hide all sections
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => section.classList.add('hidden'));

    // Show the selected section
    document.getElementById(sectionId).classList.remove('hidden');
}

function toggleArticle(articleId) {
    const article = document.getElementById(articleId);
    article.classList.toggle('hidden');
}

