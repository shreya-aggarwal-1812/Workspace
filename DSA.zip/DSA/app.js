const API_BASE = 'http://127.0.0.1:5000/api';
let appData = {
  term: 4,
  subjects: [],
  classes: {},
  sessions: {}
};

const appRoot = document.getElementById('app-root');

async function initApp() {
  if(window.lucide) { lucide.createIcons(); }
  setupThemeToggle();
  
  try {
    const res = await fetch(`${API_BASE}/data`);
    const data = await res.json();
    appData = data;
    
    populateSidebar();
    setupSidebarDropdowns();
    renderDashboard();
  } catch (err) {
    appRoot.innerHTML = `<div class="card"><h2 style="color:var(--primary-color)">Backend Connection Failed</h2>
      <p>Ensure the Python Flask server is running at ${API_BASE}.</p></div>`;
  }
}

function setupThemeToggle() {
  const toggleBtn = document.getElementById('theme-toggle');
  let isDark = false;
  toggleBtn.addEventListener('click', () => {
    isDark = !isDark;
    if (isDark) {
      document.body.setAttribute('data-theme', 'dark');
      toggleBtn.innerHTML = '<i data-lucide="sun"></i> <span>Light Mode</span>';
    } else {
      document.body.removeAttribute('data-theme');
      toggleBtn.innerHTML = '<i data-lucide="moon"></i> <span>Dark Mode</span>';
    }
    if(window.lucide) lucide.createIcons();
  });
}

function setupSidebarDropdowns() {
  window.toggleDropdown = function(menuId) {
    const menu = document.getElementById(menuId);
    const title = menu.previousElementSibling;
    if (menu.style.display === 'none') {
      menu.style.display = 'block';
      title.classList.add('open');
    } else {
      menu.style.display = 'none';
      title.classList.remove('open');
    }
  };

  const navDashboard = document.querySelector('.nav-item[data-view="dashboard"]');
  navDashboard.addEventListener('click', () => {
    document.querySelectorAll('.nav-subitem').forEach(el => el.classList.remove('active'));
    navDashboard.classList.add('active');
    renderDashboard();
  });
}

function populateSidebar() {
  const term4Menu = document.getElementById('term4-menu');
  let html = '';
  appData.subjects.forEach(sub => {
    html += `<li class="nav-subitem" id="sidebar-sub-${sub.id}" onclick="navigateToSubject('${sub.id}')">${sub.name}</li>`;
  });
  term4Menu.innerHTML = html;
}

window.navigateToSubject = function(subjectId) {
  document.querySelector('.nav-item[data-view="dashboard"]').classList.remove('active');
  document.querySelectorAll('.nav-subitem').forEach(el => el.classList.remove('active'));
  document.getElementById('sidebar-sub-' + subjectId).classList.add('active');
  renderSubject(subjectId);
};

function renderDashboard() {
  let html = `
    <div>
      <h1 class="mb-4">Dashboard Overview</h1>
      <p class="text-muted mb-4">View your upcoming sessions and attendance limits. Navigate to specific subjects using the Term dropdowns in the sidebar.</p>
      
      <div class="card" style="padding: 0; overflow: hidden;">
        <table class="dashboard-table">
          <thead style="background-color: var(--surface-color-alt);">
            <tr>
              <th>Subject</th>
              <th>Next Upcoming Session</th>
              <th>Attendance Rules & Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  appData.subjects.forEach(sub => {
    const sessions = appData.sessions[sub.id] || [];
    
    let attendedCount = 0;
    let missedCount = 0;
    let dueCount = 0;
    let nextSession = null;

    sessions.forEach(s => {
      if (s.status === 'attended') attendedCount++;
      else if (s.status === 'missed') missedCount++;
      else {
        dueCount++;
        if (!nextSession) nextSession = s;
      }
    });

    if (!nextSession) nextSession = { name: 'All Completed' };
    const maxMiss = sub.classCount === 20 ? 4 : 2;
    
    html += `
            <tr>
              <td><strong>${sub.name}</strong> <span style="font-size:0.8rem" class="text-muted">(${sub.category})</span></td>
              <td>${nextSession.name}</td>
              <td>
                <div class="mb-2"><span class="badge">Can miss ${maxMiss} classes</span></div>
                <div class="text-sm">
                   <span style="color:#10b981; font-weight:bold">${attendedCount} Attended</span> | 
                   <span style="color:#ef4444; font-weight:bold">${missedCount} Missed</span> | 
                   <span style="color:#9ca3af; font-weight:bold">${dueCount} Due</span>
                </div>
              </td>
            </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;
  appRoot.innerHTML = html;
  if(window.lucide) lucide.createIcons();
}

window.renderSubject = function(subjectId) {
  const subject = appData.subjects.find(s => s.id === subjectId);
  const classes = appData.classes[subjectId] || [];
  const sessions = appData.sessions[subjectId] || [];

  let html = `
    <div>
      <h1 class="mb-4">${subject.name} <span class="badge">${subject.category}</span></h1>
      
      <div class="tabs">
        <div class="tab active" data-tab="academic">Academic Session Planner</div>
        <div class="tab" data-tab="classes">Classes & Cases</div>
      </div>

      <div class="tab-content active" id="tab-academic">
        <div class="card">
          <h2>Attendance Schedule</h2>
          <p class="text-muted mb-4">You have ${subject.classCount} sessions. You can safely miss ${subject.classCount === 20 ? 4 : 2} sessions.</p>
          <div style="max-height: 500px; overflow-y: auto; padding-right: 1rem;">
            ${sessions.map(s => `
              <div class="session-item">
                <span style="flex:1"><strong>${s.name}</strong></span>
                <div class="segmented-control">
                  <div class="segment ${s.status === 'due' ? 'active-due' : ''}" onclick="updateAttendanceStatus('${subjectId}', ${s.id}, 'due')">Due</div>
                  <div class="segment ${s.status === 'attended' ? 'active-attended' : ''}" onclick="updateAttendanceStatus('${subjectId}', ${s.id}, 'attended')">Attended</div>
                  <div class="segment ${s.status === 'missed' ? 'active-missed' : ''}" onclick="updateAttendanceStatus('${subjectId}', ${s.id}, 'missed')">Missed</div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <div class="tab-content" id="tab-classes">
        <div class="card">
          <h2>Class List</h2>
          ${classes.length === 0 ? '<p class="text-muted">No classes scheduled.</p>' : `
            <ul class="nav-menu mt-4">
              ${classes.map(c => `
                <li class="nav-item" style="border:1px solid var(--border-color); margin-bottom:0.5rem;" onclick="renderClassDetail('${c.id}', '${subjectId}')">
                  <div class="flex justify-between w-100" style="width:100%">
                    <span><strong>${c.title}</strong></span>
                    <span class="text-muted text-sm">${c.date}</span>
                  </div>
                </li>
              `).join('')}
            </ul>
          `}
        </div>
      </div>
    </div>
  `;
  appRoot.innerHTML = html;
  if(window.lucide) lucide.createIcons();
  setupTabs();
};

window.updateAttendanceStatus = async function(subjectId, sessionId, status) {
  // Update UI immediately
  const session = appData.sessions[subjectId].find(s => s.id === sessionId);
  if(session) session.status = status;
  
  renderSubject(subjectId); // Re-render to reflect new segmented control state
  
  // Call backend
  try {
    await fetch(`${API_BASE}/attendance`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: sessionId, status: status })
    });
  } catch (err) {
    console.error("Failed to sync attendance", err);
  }
};

window.renderClassDetail = function(classId, subjectId) {
  const classObj = appData.classes[subjectId].find(c => c.id === classId);
  const title = classObj ? classObj.title : 'Class Details';

  let html = `
    <div>
      <div class="flex items-center gap-2 mb-4" style="cursor:pointer" onclick="renderSubject('${subjectId}')">
        <i data-lucide="arrow-left"></i> <span class="text-muted">Back to Subject</span>
      </div>
      <h1 class="mb-4">${title}</h1>
      
      <div class="tabs">
        <div class="tab active" data-tab="reading">Materials</div>
        <div class="tab" data-tab="questions">Analysis Q&A</div>
        <div class="tab" data-tab="quiz">Quiz Generation</div>
        <div class="tab" data-tab="media">Media Context</div>
      </div>

      <div class="tab-content active" id="tab-reading">
        <div class="card">
          <h2>Class Materials</h2>
          <p class="text-muted mb-4">Upload the case study and any relevant reading for this specific class.</p>
          
          <div class="grid-2">
            <!-- Case Upload -->
            <div class="upload-zone" style="height: 200px" onclick="document.getElementById('case-upload').click()">
              <i data-lucide="upload-cloud" style="width:40px;height:40px;color:var(--primary-color)"></i>
              <h3 class="mt-2 text-md">Upload Case PDF</h3>
              ${classObj.case_pdf ? `<p class="text-sm" style="color:green">File: ${classObj.case_pdf}</p>` : ''}
              <input type="file" id="case-upload" class="hidden" onchange="uploadDocument('${classId}', 'case', this)">
            </div>
            
            <!-- Reading Upload -->
            <div class="upload-zone" style="height: 200px" onclick="document.getElementById('reading-upload').click()">
              <i data-lucide="book-open" style="width:40px;height:40px;color:var(--secondary-color)"></i>
              <h3 class="mt-2 text-md">Upload Relevant Reading</h3>
              <p class="text-muted text-sm">(Optional)</p>
              ${classObj.reading_pdf ? `<p class="text-sm" style="color:green">File: ${classObj.reading_pdf}</p>` : ''}
              <input type="file" id="reading-upload" class="hidden" onchange="uploadDocument('${classId}', 'reading', this)">
            </div>
          </div>
        </div>
      </div>

      <div class="tab-content" id="tab-questions">
        <div class="card">
          <h2>Generate Case Answer</h2>
          <p class="text-muted mb-4">Input your question and specifications to generate an analysis answer via the backend.</p>
          
          <div class="form-group">
            <label>Question to Answer</label>
            <input type="text" id="qa-question" placeholder="e.g. What is the primary competitive advantage?">
          </div>
          
          <div class="form-group">
            <label>Word Limit</label>
            <select id="qa-word-limit">
              <option value="50-100">50 - 100 words</option>
              <option value="100-150">100 - 150 words</option>
              <option value="150-200">150 - 200 words</option>
              <option value="200-250">200 - 250 words</option>
              <option value="250-300">250 - 300 words</option>
            </select>
          </div>

          <div class="form-group">
            <label>Other Specifications</label>
            <textarea id="qa-specs" rows="3" placeholder="e.g. Focus on financial metrics or use specific terminology..."></textarea>
          </div>
          
          <button class="btn btn-primary" onclick="generateQA('${classId}')">Generate Answer</button>

          <div id="qa-result-container" class="hidden qa-result">
            <h3>Generated Answer</h3>
            <p id="qa-result-text" class="text-muted"></p>
          </div>
        </div>
      </div>

      <div class="tab-content" id="tab-quiz">
        <div class="card">
          <h2>Quiz Generation</h2>
          <p class="text-muted mb-4">Generate MCQs based on the uploaded case via the backend.</p>
          
          <button class="btn btn-secondary mb-4" onclick="generateQuiz('${classId}')">Generate Quiz</button>
          
          <div id="quiz-container" class="hidden">
             <!-- Injected by generateQuiz() -->
          </div>
        </div>
      </div>

      <div class="tab-content" id="tab-media">
        <div class="card">
          <h2>Related Media</h2>
          <div style="background:#111; height:300px; border-radius:0.5rem; display:flex; flex-direction:column; align-items:center; justify-content:center;">
             <i data-lucide="youtube" style="color:var(--primary-color); width:64px; height:64px"></i>
             <span style="color:white; margin-top:1rem; font-weight:600;">Mock YouTube Player</span>
          </div>
        </div>
      </div>

    </div>
  `;
  appRoot.innerHTML = html;
  if(window.lucide) lucide.createIcons();
  setupTabs();
};

window.uploadDocument = async function(classId, docType, inputElement) {
  if(!inputElement.files[0]) return;
  const file = inputElement.files[0];
  
  const formData = new FormData();
  formData.append('file', file);
  formData.append('class_id', classId);
  formData.append('doc_type', docType);

  try {
    const res = await fetch(`${API_BASE}/upload`, {
      method: 'POST',
      body: formData
    });
    const data = await res.json();
    if(data.success) {
      alert(`File uploaded successfully: ${data.filename}`);
      initApp(); // Full refresh for simplicity
    }
  } catch (err) {
    alert("File upload failed. Make sure backend is running.");
  }
};

window.generateQA = async function(classId) {
  const q = document.getElementById('qa-question').value;
  const limit = document.getElementById('qa-word-limit').value;
  const specs = document.getElementById('qa-specs').value;
  
  if(!q) { alert("Please enter a question first."); return; }

  const resultContainer = document.getElementById('qa-result-container');
  const resultText = document.getElementById('qa-result-text');
  
  resultContainer.classList.remove('hidden');
  resultText.innerHTML = `<em>Generating analysis via backend...</em>`;
  
  try {
    const res = await fetch(`${API_BASE}/generate_qa`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ class_id: classId, question: q, word_limit: limit, specs: specs })
    });
    const data = await res.json();
    resultText.innerHTML = data.answer;
  } catch(err) {
    resultText.innerHTML = `<span style="color:red">Backend connection failed.</span>`;
  }
};

window.generateQuiz = async function(classId) {
  const container = document.getElementById('quiz-container');
  container.classList.remove('hidden');
  container.innerHTML = `<p class="text-muted">Fetching quiz from backend...</p>`;
  
  try {
    const res = await fetch(`${API_BASE}/generate_quiz`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ class_id: classId })
    });
    const data = await res.json();
    
    if(data.quiz && data.quiz.length > 0) {
      const q = data.quiz[0]; // Just showing the first mock question
      container.innerHTML = `
        <div class="form-group" style="border-top:1px solid var(--border-color); padding-top:1rem;">
          <label>1. ${q.question}</label>
          <div class="mt-2" style="display:flex; flex-direction:column; gap:0.5rem;">
            ${q.options.map((opt, i) => `
              <label style="font-weight:normal">
                <input type="radio" name="mock_q1" value="${i}"> ${opt}
              </label>
            `).join('')}
          </div>
        </div>
        <button class="btn btn-primary mt-2" onclick="alert('Result verified by backend!')">Submit Quiz</button>
      `;
    }
  } catch (err) {
    container.innerHTML = `<p style="color:red">Failed to reach backend.</p>`;
  }
};

function setupTabs() {
  const tabs = document.querySelectorAll('.tab');
  const contents = document.querySelectorAll('.tab-content');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      contents.forEach(c => c.classList.remove('active'));

      tab.classList.add('active');
      const target = tab.getAttribute('data-tab');
      document.getElementById('tab-' + target).classList.add('active');
    });
  });
}

initApp();
