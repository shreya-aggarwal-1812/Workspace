import sqlite3
import os

DB_PATH = 'study_planner.db'

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    
    # Create Subjects Table
    c.execute('''
        CREATE TABLE IF NOT EXISTS subjects (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            class_count INTEGER NOT NULL
        )
    ''')
    
    # Create Classes Table
    c.execute('''
        CREATE TABLE IF NOT EXISTS classes (
            id TEXT PRIMARY KEY,
            subject_id TEXT NOT NULL,
            title TEXT NOT NULL,
            date TEXT NOT NULL,
            case_pdf TEXT,
            reading_pdf TEXT,
            FOREIGN KEY (subject_id) REFERENCES subjects(id)
        )
    ''')

    # Create Sessions Table (status: 'due', 'attended', 'missed')
    c.execute('''
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_id TEXT NOT NULL,
            session_num INTEGER NOT NULL,
            name TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'due',
            FOREIGN KEY (subject_id) REFERENCES subjects(id)
        )
    ''')
    
    # Populate Initial Data if empty
    c.execute('SELECT COUNT(*) FROM subjects')
    if c.fetchone()[0] == 0:
        subjects = [
            # Marketing & Strategy
            ('s1', 'Pricing Strategies', 'Marketing & Strategy', 20),
            ('s2', 'AIDMD', 'Marketing & Strategy', 20),
            ('s3', 'GBS', 'Marketing & Strategy', 20),
            # Finance
            ('s4', 'IMDM', 'Finance', 20),
            # Operations
            ('s5', 'Project Management', 'Operations', 20),
            ('s6', 'Sustainability', 'Operations', 10),
            # MIS
            ('s7', 'DBM', 'MIS', 20),
            ('s8', 'Python', 'MIS', 10)
        ]
        c.executemany('INSERT INTO subjects (id, name, category, class_count) VALUES (?, ?, ?, ?)', subjects)
        
        dbm_topics = [
            "Platform Thinking: Genesis of Platforms",
            "Understanding Online Competition",
            "Winner-Take-All Competition",
            "Building Online Platforms",
            "Launching Platforms: Acquiring customers",
            "Designing the Business Model",
            "Community Driven Value",
            "Third-party in Value Creation",
            "Value through Disruption",
            "Platform Failure",
            "Mistiming and Hubris",
            "Mastering Intermediaries",
            "Battle of Intermediaries",
            "Dealing with Emerging Players",
            "Responsible Platform",
            "Responding to Unchartered Issues",
            "New Platform Battleground",
            "Emerging or Future of Platforms",
            "Project Presentation 1",
            "Project Presentation 2"
        ]

        imdm_topics = [
            "Risk, Uncertainty, and Decision Making",
            "Structure of Insurance Markets",
            "Operations of Insurers",
            "Adverse Selection and Moral hazard",
            "Insuring the Inevitable: Death",
            "Pricing Mortality, Savings, and Intergenerational Transfers",
            "Health Risk and Insurance Design",
            "Designing Care",
            "Protecting the Nest: Homeowners Insurance",
            "Firms Under Fire: Managing Property and Liability Risks",
            "Risk on Wheels",
            "Niche Risks and Hidden Exposures",
            "The State as Insurer",
            "Outliving Income: Retirement Benefits",
            "Who Insures the Insurers?",
            "Catastrophic Risks",
            "Governing Risk: Regulation as Constraint and Strategy",
            "Future of Insurance",
            "Project Presentation 1",
            "Project Presentation 2"
        ]

        aidmd_topics = [
            "AI in Marketing - The Big Picture",
            "Generative AI & Marketing Creativity",
            "AI Business Models",
            "Agentic AI & Autonomous Marketing",
            "Managing Autonomous Marketing Systems",
            "AI in Retail Experience",
            "AI-driven Recommendation Systems",
            "AI and Customer-Centric Marketing Strategy",
            "Customer Trust and Adoption of AI in Marketing",
            "Managing Customer Resistance to AI in Marketing",
            "AI in Marketing Agencies",
            "Conversational AI in Marketing",
            "AI Deployment Decision-Making",
            "AI Business Models & Customer Delight",
            "AI-Driven Search and Discovery Systems",
            "AI in Visual Search and E-commerce Discovery",
            "Algorithmic Bias and Responsible AI in Marketing",
            "Project Presentation and Feedback 1",
            "Project Presentation and Feedback 2",
            "AI in Marketing: Myths, Lessons, and Strategic Implications"
        ]

        for sub_id, name, category, count in subjects:
            classes = []
            sessions = []
            for i in range(1, count + 1):
                # Inject syllabus if matches subject id
                if sub_id == 's7' and i <= len(dbm_topics):
                    title = f"Class {i}: {dbm_topics[i-1]}"
                    session_name = f"Session {i}: {dbm_topics[i-1]}"
                elif sub_id == 's4' and i <= len(imdm_topics):
                    title = f"Class {i}: {imdm_topics[i-1]}"
                    session_name = f"Session {i}: {imdm_topics[i-1]}"
                elif sub_id == 's2' and i <= len(aidmd_topics):
                    title = f"Class {i}: {aidmd_topics[i-1]}"
                    session_name = f"Session {i}: {aidmd_topics[i-1]}"
                else:
                    title = f"Class {i}: Topic {i}"
                    session_name = f"Session {i}"
                    
                classes.append((f"{sub_id}-c{i}", sub_id, title, "TBD", None, None))
                sessions.append((sub_id, i, session_name, 'due'))
                
            c.executemany('INSERT INTO classes (id, subject_id, title, date, case_pdf, reading_pdf) VALUES (?, ?, ?, ?, ?, ?)', classes)
            c.executemany('INSERT INTO sessions (subject_id, session_num, name, status) VALUES (?, ?, ?, ?)', sessions)

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database initialized successfully.")
