import os
import time
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
import database
import re

# Import the NEW SDK
from google import genai 

app = Flask(__name__)
CORS(app) # Allow frontend to make requests

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Initialize DB on startup
database.init_db()

# Initialize the new client with your AQ. key
# Be sure to paste your actual key here!
client = genai.Client(api_key="AQ.Ab8RN6JhDq6-XKPjI8Y0Ao758mTFYVgWNy4G38Bl8fyCf8e8VA")

@app.route('/api/data', methods=['GET'])
def get_data():
    conn = database.get_db()
    c = conn.cursor()
    
    # Fetch Subjects
    c.execute('SELECT * FROM subjects')
    subjects = [dict(row) for row in c.fetchall()]
    
    # Structure data for frontend
    data = {
        'term': 4,
        'subjects': subjects,
        'classes': {},
        'sessions': {}
    }
    
    for sub in subjects:
        sub_id = sub['id']
        # Progress mock (random logic or 0)
        sub['progress'] = 0 

        c.execute('SELECT * FROM classes WHERE subject_id = ?', (sub_id,))
        data['classes'][sub_id] = [dict(row) for row in c.fetchall()]
        
        c.execute('SELECT * FROM sessions WHERE subject_id = ? ORDER BY session_num', (sub_id,))
        data['sessions'][sub_id] = [dict(row) for row in c.fetchall()]
        
    conn.close()
    return jsonify(data)

@app.route('/api/attendance', methods=['POST'])
def update_attendance():
    payload = request.json
    session_id = payload.get('session_id')
    status = payload.get('status')
    
    if session_id is None or status not in ['attended', 'missed', 'due']:
        return jsonify({'error': 'Invalid data'}), 400
        
    conn = database.get_db()
    c = conn.cursor()
    c.execute('UPDATE sessions SET status = ? WHERE id = ?', (status, session_id))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
        
    class_id = request.form.get('class_id')
    doc_type = request.form.get('doc_type') # 'case' or 'reading'
    
    if file:
        filename = secure_filename(file.filename)
        # Store uniquely
        final_filename = f"{class_id}_{doc_type}_{filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], final_filename)
        file.save(filepath)
        
        # Update DB
        conn = database.get_db()
        c = conn.cursor()
        col = 'case_pdf' if doc_type == 'case' else 'reading_pdf'
        c.execute(f'UPDATE classes SET {col} = ? WHERE id = ?', (final_filename, class_id))
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'filename': final_filename})

@app.route('/api/generate_qa', methods=['POST'])
def generate_qa():
    payload = request.json
    question = payload.get('question', '')
    word_limit = payload.get('word_limit', '')
    specs = payload.get('specs', '')
    class_id = payload.get('class_id') # Extract class_id sent from frontend

    uploaded_files_to_clean = []
    contents_payload = []

    try:
        # 1. Look up PDF filenames in SQLite if class_id was provided
        if class_id:
            conn = database.get_db()
            c = conn.cursor()
            c.execute('SELECT case_pdf, reading_pdf FROM classes WHERE id = ?', (class_id,))
            class_row = c.fetchone()
            conn.close()

            if class_row:
                # Upload Case PDF if present
                if class_row['case_pdf']:
                    case_path = os.path.join(app.config['UPLOAD_FOLDER'], class_row['case_pdf'])
                    if os.path.exists(case_path):
                        case_file_ref = client.files.upload(file=case_path)
                        contents_payload.append(case_file_ref)
                        uploaded_files_to_clean.append(case_file_ref)

                # Upload Reading PDF if present
                if class_row['reading_pdf']:
                    reading_path = os.path.join(app.config['UPLOAD_FOLDER'], class_row['reading_pdf'])
                    if os.path.exists(reading_path):
                        reading_file_ref = client.files.upload(file=reading_path)
                        contents_payload.append(reading_file_ref)
                        uploaded_files_to_clean.append(reading_file_ref)

        # 2. Build Prompt
	# Update Prompt with explicit formatting instructions
        prompt_text = f"""
        You are an expert MBA case study analyst. 
        Analyze the attached case study and/or reading material to answer the question below.
        
        Question: {question}
        
        Formatting & Style Requirements:
        - Format your response using clean Markdown with clear headings (`###`) and distinct bullet points.
        - ALWAYS put each bullet point or section on a NEW LINE (use line breaks between points).
        - Do not lump facts into a single dense paragraph.
        - Strict length limit: {word_limit} words.
        - Additional user specifications: {specs}
        """
        contents_payload.append(prompt_text)

        # 3. Generate response with PDF attachments attached
        response = client.models.generate_content(
            model='gemini-3.6-flash',
            contents=contents_payload,
        )
        answer_text = response.text
        answer_text = re.sub(r'#+\s*', '', answer_text)
        answer_text = answer_text.replace('**', '').replace('* ', '• ')

    except Exception as e:
        answer_text = f"Error calling AI: {str(e)}"
    
    finally:
        # 4. Clean up temporary Gemini uploads
        for file_ref in uploaded_files_to_clean:
            try:
                client.files.delete(name=file_ref.name)
            except Exception:
                pass

    return jsonify({'answer': answer_text})

@app.route('/api/generate_quiz', methods=['POST'])
def generate_quiz():
    payload = request.json
    class_id = payload.get('class_id')
    
    # MOCK AI Logic
    time.sleep(1)
    mock_quiz = [
        {
            'question': 'What is the core issue discussed in this case?',
            'options': ['Market Entry', 'Cost Cutting', 'Vertical Integration', 'Leadership Turnover'],
            'correct_index': 2
        }
    ]
    return jsonify({'quiz': mock_quiz})

if __name__ == '__main__':
    print("Starting backend server...")
    app.run(debug=True, port=5000)